import React, { useEffect, useState } from "react";
import { Card, Table, Button, Modal, Form, Alert, Badge, Row, Col } from "react-bootstrap";
import api from "../api/axios";
import { ROLE_LABELS } from "../context/AuthContext";

const EMPTY_FORM = { name: "", email: "", password: "", role: "hod", department: "" };

export default function Users() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const load = () => {
    api
      .get("/users")
      .then((res) => setUsers(res.data.users))
      .catch((err) => setError(err?.response?.data?.error || "Could not load users."));
  };

  useEffect(load, []);

  const openCreate = () => {
    setForm(EMPTY_FORM);
    setError("");
    setSuccess("");
    setShowModal(true);
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.post("/users", form);
      setSuccess(`User ${form.email} created successfully.`);
      setShowModal(false);
      load();
    } catch (err) {
      setError(err?.response?.data?.error || "Could not create user.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (u) => {
    try {
      await api.put(`/users/${u.id}`, { is_active: u.is_active ? 0 : 1 });
      load();
    } catch (err) {
      setError(err?.response?.data?.error || "Could not update user.");
    }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 className="mb-0">User Management</h4>
          <p className="text-muted mb-0">Create accounts and grant role-based access. Email is the unique login ID.</p>
        </div>
        <Button className="btn-plasu" onClick={openCreate}>+ New User</Button>
      </div>

      {error && <Alert variant="danger" onClose={() => setError("")} dismissible>{error}</Alert>}
      {success && <Alert variant="success" onClose={() => setSuccess("")} dismissible>{success}</Alert>}

      <Card className="plasu-card p-3">
        <Table responsive hover className="table-plasu mb-0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Department</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{ROLE_LABELS[u.role] || u.role}</td>
                <td>{u.department || "—"}</td>
                <td>
                  <Badge bg={u.is_active ? "success" : "secondary"}>
                    {u.is_active ? "Active" : "Deactivated"}
                  </Badge>
                </td>
                <td>
                  <Button size="sm" variant="outline-secondary" onClick={() => toggleActive(u)}>
                    {u.is_active ? "Deactivate" : "Activate"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Create New User</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleCreate}>
          <Modal.Body>
            {error && <Alert variant="danger">{error}</Alert>}
            <Row>
              <Col md={12} className="mb-3">
                <Form.Label>Full Name</Form.Label>
                <Form.Control
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </Col>
              <Col md={12} className="mb-3">
                <Form.Label>Email (login ID)</Form.Label>
                <Form.Control
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </Col>
              <Col md={12} className="mb-3">
                <Form.Label>Temporary Password</Form.Label>
                <Form.Control
                  type="text"
                  required
                  minLength={6}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                />
              </Col>
              <Col md={6} className="mb-3">
                <Form.Label>Role</Form.Label>
                <Form.Select
                  value={form.role}
                  onChange={(e) => setForm({ ...form, role: e.target.value })}
                >
                  <option value="hod">Head of Department</option>
                  <option value="inventoryadmin">Inventory Admin</option>
                  <option value="technical_expert">Technical Expert</option>
                  <option value="audit_officer">Audit Officer</option>
                  <option value="asset_officer">Asset / Insurance Officer</option>
                  <option value="ictadmin">ICT Admin</option>
                  <option value="superadmin">Super Admin</option>
                </Form.Select>
              </Col>
              <Col md={6} className="mb-3">
                <Form.Label>Department / Unit</Form.Label>
                <Form.Control
                  value={form.department}
                  onChange={(e) => setForm({ ...form, department: e.target.value })}
                />
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
            <Button type="submit" className="btn-plasu" disabled={saving}>
              {saving ? "Saving…" : "Create User"}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </>
  );
}
