import React, { useEffect, useState } from "react";
import { Card, Table, Button, Modal, Form, Alert, Badge, Row, Col } from "react-bootstrap";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const EMPTY_ITEM = { code: "", name: "", description: "", unit: "ea", quantity_on_hand: 0, reorder_level: 0 };

export default function Inventory() {
  const { user } = useAuth();
  const canAddItems = user.role === "superadmin" || user.role === "ictadmin";
  const canReceiveStock = user.role === "inventoryadmin" || canAddItems;

  const [items, setItems] = useState([]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState(EMPTY_ITEM);
  const [receiveTarget, setReceiveTarget] = useState(null);
  const [receiveQty, setReceiveQty] = useState("");
  const [receiveRemarks, setReceiveRemarks] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () => {
    api
      .get("/items")
      .then((res) => setItems(res.data.items))
      .catch((err) => setError(err?.response?.data?.error || "Could not load inventory."));
  };

  useEffect(load, []);

  const handleAddItem = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.post("/items", newItem);
      setSuccess(`Item "${newItem.name}" added to inventory.`);
      setShowAdd(false);
      setNewItem(EMPTY_ITEM);
      load();
    } catch (err) {
      setError(err?.response?.data?.error || "Could not add item.");
    } finally {
      setSaving(false);
    }
  };

  const handleReceive = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.post(`/items/${receiveTarget.id}/receive`, {
        qty: Number(receiveQty),
        remarks: receiveRemarks,
      });
      setSuccess(`Stock received for "${receiveTarget.name}".`);
      setReceiveTarget(null);
      setReceiveQty("");
      setReceiveRemarks("");
      load();
    } catch (err) {
      setError(err?.response?.data?.error || "Could not record stock receipt.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 className="mb-0">Inventory</h4>
          <p className="text-muted mb-0">
            Available store items{canAddItems ? " — add new items or " : ""}
            {canReceiveStock ? "record incoming stock." : "."}
          </p>
        </div>
        {canAddItems && (
          <Button className="btn-plasu" onClick={() => { setShowAdd(true); setError(""); }}>
            + Add Item
          </Button>
        )}
      </div>

      {error && <Alert variant="danger" onClose={() => setError("")} dismissible>{error}</Alert>}
      {success && <Alert variant="success" onClose={() => setSuccess("")} dismissible>{success}</Alert>}

      <Card className="plasu-card p-3">
        <Table responsive hover className="table-plasu mb-0">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Unit</th>
              <th>On Hand</th>
              <th>Reorder Level</th>
              <th>Status</th>
              {canReceiveStock && <th></th>}
            </tr>
          </thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.id}>
                <td>{i.code}</td>
                <td>{i.name}<div className="text-muted small">{i.description}</div></td>
                <td>{i.unit}</td>
                <td>{i.quantity_on_hand}</td>
                <td>{i.reorder_level}</td>
                <td>
                  {i.quantity_on_hand <= i.reorder_level ? (
                    <Badge bg="warning" text="dark">Low Stock</Badge>
                  ) : (
                    <Badge bg="success">Healthy</Badge>
                  )}
                </td>
                {canReceiveStock && (
                  <td>
                    <Button size="sm" variant="outline-secondary" onClick={() => setReceiveTarget(i)}>
                      Receive Stock
                    </Button>
                  </td>
                )}
              </tr>
            ))}
            {items.length === 0 && (
              <tr><td colSpan={7} className="text-center text-muted">No items in inventory.</td></tr>
            )}
          </tbody>
        </Table>
      </Card>

      {/* Add item modal */}
      <Modal show={showAdd} onHide={() => setShowAdd(false)}>
        <Modal.Header closeButton><Modal.Title>Add Inventory Item</Modal.Title></Modal.Header>
        <Form onSubmit={handleAddItem}>
          <Modal.Body>
            <Row>
              <Col md={6} className="mb-3">
                <Form.Label>Item Code</Form.Label>
                <Form.Control required value={newItem.code} onChange={(e) => setNewItem({ ...newItem, code: e.target.value })} />
              </Col>
              <Col md={6} className="mb-3">
                <Form.Label>Unit of Measure</Form.Label>
                <Form.Control required value={newItem.unit} onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })} placeholder="e.g. ea, ream, carton" />
              </Col>
              <Col md={12} className="mb-3">
                <Form.Label>Item Name</Form.Label>
                <Form.Control required value={newItem.name} onChange={(e) => setNewItem({ ...newItem, name: e.target.value })} />
              </Col>
              <Col md={12} className="mb-3">
                <Form.Label>Description</Form.Label>
                <Form.Control as="textarea" rows={2} value={newItem.description} onChange={(e) => setNewItem({ ...newItem, description: e.target.value })} />
              </Col>
              <Col md={6} className="mb-3">
                <Form.Label>Opening Quantity</Form.Label>
                <Form.Control type="number" min="0" value={newItem.quantity_on_hand} onChange={(e) => setNewItem({ ...newItem, quantity_on_hand: e.target.value })} />
              </Col>
              <Col md={6} className="mb-3">
                <Form.Label>Reorder Level</Form.Label>
                <Form.Control type="number" min="0" value={newItem.reorder_level} onChange={(e) => setNewItem({ ...newItem, reorder_level: e.target.value })} />
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button type="submit" className="btn-plasu" disabled={saving}>{saving ? "Saving…" : "Add Item"}</Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Receive stock modal */}
      <Modal show={!!receiveTarget} onHide={() => setReceiveTarget(null)}>
        <Modal.Header closeButton><Modal.Title>Receive Stock: {receiveTarget?.name}</Modal.Title></Modal.Header>
        <Form onSubmit={handleReceive}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Quantity Received ({receiveTarget?.unit})</Form.Label>
              <Form.Control type="number" min="1" required value={receiveQty} onChange={(e) => setReceiveQty(e.target.value)} />
            </Form.Group>
            <Form.Group>
              <Form.Label>Remarks (optional)</Form.Label>
              <Form.Control as="textarea" rows={2} value={receiveRemarks} onChange={(e) => setReceiveRemarks(e.target.value)} placeholder="e.g. Supplier / delivery reference" />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setReceiveTarget(null)}>Cancel</Button>
            <Button type="submit" className="btn-plasu" disabled={saving}>{saving ? "Saving…" : "Confirm Receipt"}</Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </>
  );
}
