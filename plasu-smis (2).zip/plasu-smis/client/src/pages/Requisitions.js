import React, { useEffect, useState } from "react";
import { Card, Table, Button, Alert } from "react-bootstrap";
import { Link } from "react-router-dom";
import api from "../api/axios";
import StatusBadge from "../components/StatusBadge";
import { useAuth } from "../context/AuthContext";

export default function Requisitions() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/requisitions")
      .then((res) => setRows(res.data.requisitions))
      .catch((err) => setError(err?.response?.data?.error || "Could not load requisitions."));
  }, []);

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 className="mb-0">Requisitions</h4>
          <p className="text-muted mb-0">
            {user.role === "hod" ? "Your requisitions and their approval status." : "All requisitions raised across departments."}
          </p>
        </div>
        {user.role === "hod" && (
          <Button as={Link} to="/requisitions/new" className="btn-plasu">+ New Requisition</Button>
        )}
      </div>

      {error && <Alert variant="danger">{error}</Alert>}

      <Card className="plasu-card p-3">
        <Table responsive hover className="table-plasu mb-0">
          <thead>
            <tr>
              <th>SRV No.</th>
              <th>Department</th>
              <th>Purpose</th>
              <th>Status</th>
              <th>Date</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.req_no}</td>
                <td>{r.department}</td>
                <td>{r.purpose}</td>
                <td><StatusBadge status={r.status} /></td>
                <td>{new Date(r.created_at).toLocaleDateString()}</td>
                <td>
                  <Button as={Link} to={`/requisitions/${r.id}`} size="sm" className="btn-outline-plasu">
                    View
                  </Button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={6} className="text-center text-muted">No requisitions found.</td></tr>
            )}
          </tbody>
        </Table>
      </Card>
    </>
  );
}
