import React, { useEffect, useState } from "react";
import { Card, Table, Alert, Badge } from "react-bootstrap";
import api from "../api/axios";

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/audit")
      .then((res) => setLogs(res.data.logs))
      .catch((err) => setError(err?.response?.data?.error || "Could not load audit log."));
  }, []);

  return (
    <>
      <h4>Audit Log</h4>
      <p className="text-muted">System-wide activity trail for accountability and oversight.</p>
      {error && <Alert variant="danger">{error}</Alert>}
      <Card className="plasu-card p-3">
        <Table responsive hover size="sm" className="table-plasu mb-0">
          <thead>
            <tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.id}>
                <td>{new Date(log.created_at).toLocaleString()}</td>
                <td>{log.actor_email || "—"}</td>
                <td><Badge bg="secondary">{log.action}</Badge></td>
                <td>{log.entity_type} #{log.entity_id}</td>
                <td className="text-muted small">{log.details}</td>
              </tr>
            ))}
            {logs.length === 0 && <tr><td colSpan={5} className="text-center text-muted">No activity recorded yet.</td></tr>}
          </tbody>
        </Table>
      </Card>
    </>
  );
}
