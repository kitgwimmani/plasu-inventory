import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import Inventory from "./pages/Inventory";
import Requisitions from "./pages/Requisitions";
import CreateRequisition from "./pages/CreateRequisition";
import RequisitionDetail from "./pages/RequisitionDetail";
import ChangePassword from "./pages/ChangePassword";
import AuditLog from "./pages/AuditLog";
import NotFound from "./pages/NotFound";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/inventory" element={<Inventory />} />
        <Route path="/requisitions" element={<Requisitions />} />
        <Route
          path="/requisitions/new"
          element={
            <ProtectedRoute roles={["hod"]}>
              <CreateRequisition />
            </ProtectedRoute>
          }
        />
        <Route path="/requisitions/:id" element={<RequisitionDetail />} />
        <Route
          path="/users"
          element={
            <ProtectedRoute roles={["superadmin", "ictadmin"]}>
              <Users />
            </ProtectedRoute>
          }
        />
        <Route
          path="/audit"
          element={
            <ProtectedRoute roles={["superadmin", "ictadmin"]}>
              <AuditLog />
            </ProtectedRoute>
          }
        />
        <Route path="/change-password" element={<ChangePassword />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
