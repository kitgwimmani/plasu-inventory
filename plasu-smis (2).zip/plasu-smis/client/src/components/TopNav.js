import React from "react";
import { Navbar, Nav, Container, Dropdown } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useAuth, ROLE_LABELS } from "../context/AuthContext";

export default function TopNav() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <Navbar expand="lg" className="plasu-navbar px-3" variant="dark">
      <Container fluid>
        <Navbar.Brand as={Link} to="/dashboard" className="d-flex align-items-center gap-2">
          <img src="/logo.png" alt="PLASU Bokkos logo" height="38" />
          <span className="plasu-brand-title">
            PLASU SMIS
            <small>Store Management Information System</small>
          </span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="main-navbar" />
        <Navbar.Collapse id="main-navbar">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/dashboard">Dashboard</Nav.Link>
            <Nav.Link as={Link} to="/inventory">Inventory</Nav.Link>
            <Nav.Link as={Link} to="/requisitions">Requisitions</Nav.Link>
            {(user.role === "superadmin" || user.role === "ictadmin") && (
              <Nav.Link as={Link} to="/users">Users</Nav.Link>
            )}
            {(user.role === "superadmin" || user.role === "ictadmin") && (
              <Nav.Link as={Link} to="/audit">Audit Log</Nav.Link>
            )}
          </Nav>
          <Nav>
            <Dropdown align="end">
              <Dropdown.Toggle as="a" className="nav-link" role="button" style={{ cursor: "pointer" }}>
                {user.name} <span className="text-warning">({ROLE_LABELS[user.role]})</span>
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item as={Link} to="/change-password">Change Password</Dropdown.Item>
                <Dropdown.Divider />
                <Dropdown.Item onClick={handleLogout}>Log Out</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
