import React from "react";
import { Badge } from "react-bootstrap";

const LABELS = {
  pending: "Pending Approval",
  approved: "Approved – Awaiting Signoff/Issue",
  issued: "Issued",
  rejected: "Rejected",
};

export default function StatusBadge({ status }) {
  return <Badge className={`badge-status-${status}`}>{LABELS[status] || status}</Badge>;
}
