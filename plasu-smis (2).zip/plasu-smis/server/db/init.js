// db/init.js
// SQLite schema + seed data for PLASU Store Management Information System (SMIS)
//
// Uses Node's built-in `node:sqlite` module (bundled with Node 22.5+) instead of
// better-sqlite3, so there is NO native module to compile — no Visual Studio Build
// Tools on Windows, no Xcode Command Line Tools on Mac, no python/make on Linux.
// You may see an "ExperimentalWarning: SQLite is an experimental feature" message
// on startup — that is expected and harmless.
const path = require("path");
const bcrypt = require("bcryptjs");
const { DatabaseSync } = require("node:sqlite");

const DB_PATH = path.join(__dirname, "plasu_smis.sqlite");
const raw = new DatabaseSync(DB_PATH);
raw.exec("PRAGMA foreign_keys = ON");

// Thin wrapper so the rest of the codebase can keep using the familiar
// better-sqlite3-style API: db.exec(), db.prepare(sql).run/get/all(), db.transaction(fn).
const db = {
  exec(sql) {
    raw.exec(sql);
    return db;
  },
  prepare(sql) {
    const stmt = raw.prepare(sql);
    return {
      run: (...params) => {
        const info = stmt.run(...params);
        return { lastInsertRowid: info.lastInsertRowid, changes: info.changes };
      },
      get: (...params) => stmt.get(...params),
      all: (...params) => stmt.all(...params),
    };
  },
  transaction(fn) {
    return (...args) => {
      raw.exec("BEGIN");
      try {
        const result = fn(...args);
        raw.exec("COMMIT");
        return result;
      } catch (err) {
        raw.exec("ROLLBACK");
        throw err;
      }
    };
  },
};

const ROLES = [
  "superadmin",
  "ictadmin",
  "hod",
  "inventoryadmin",
  "technical_expert",
  "audit_officer",
  "asset_officer",
];
const SIGNOFF_ROLES = ["requester", "technical_expert", "audit_officer", "asset_officer"];

function nowIso() {
  return new Date().toISOString();
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('superadmin','ictadmin','hod','inventoryadmin','technical_expert','audit_officer','asset_officer')),
      department TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_by INTEGER,
      created_at TEXT NOT NULL,
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      description TEXT,
      unit TEXT NOT NULL DEFAULT 'ea',
      quantity_on_hand REAL NOT NULL DEFAULT 0,
      reorder_level REAL NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_by INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS stock_receipts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      item_id INTEGER NOT NULL,
      qty REAL NOT NULL CHECK(qty > 0),
      remarks TEXT,
      received_by INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(item_id) REFERENCES items(id),
      FOREIGN KEY(received_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS requisitions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      req_no TEXT NOT NULL UNIQUE,
      hod_id INTEGER NOT NULL,
      department TEXT NOT NULL,
      purpose TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','issued')) DEFAULT 'pending',
      created_at TEXT NOT NULL,
      approved_by INTEGER,
      approved_at TEXT,
      rejected_by INTEGER,
      rejected_at TEXT,
      rejection_reason TEXT,
      issued_by INTEGER,
      issued_at TEXT,
      FOREIGN KEY(hod_id) REFERENCES users(id),
      FOREIGN KEY(approved_by) REFERENCES users(id),
      FOREIGN KEY(rejected_by) REFERENCES users(id),
      FOREIGN KEY(issued_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS requisition_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      requisition_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL,
      qty_requested REAL NOT NULL CHECK(qty_requested > 0),
      remarks TEXT,
      FOREIGN KEY(requisition_id) REFERENCES requisitions(id),
      FOREIGN KEY(item_id) REFERENCES items(id)
    );

    CREATE TABLE IF NOT EXISTS signoffs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      requisition_id INTEGER NOT NULL,
      role_label TEXT NOT NULL CHECK(role_label IN ('requester','technical_expert','audit_officer','asset_officer')),
      signed INTEGER NOT NULL DEFAULT 0,
      signed_by_name TEXT,
      signed_at TEXT,
      UNIQUE(requisition_id, role_label),
      FOREIGN KEY(requisition_id) REFERENCES requisitions(id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER,
      actor_email TEXT,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id INTEGER,
      details TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(actor_id) REFERENCES users(id)
    );
  `);
}

function nextReqNo() {
  const year = new Date().getFullYear();
  const row = db
    .prepare(
      `SELECT COUNT(*) AS c FROM requisitions WHERE req_no LIKE ?`
    )
    .get(`PLASU-SRV-${year}-%`);
  const next = (row.c || 0) + 1;
  return `PLASU-SRV-${year}-${String(next).padStart(4, "0")}`;
}

function audit(actorId, actorEmail, action, entityType, entityId, details) {
  db.prepare(
    `INSERT INTO audit_logs(actor_id, actor_email, action, entity_type, entity_id, details, created_at)
     VALUES (?,?,?,?,?,?,?)`
  ).run(actorId || null, actorEmail || null, action, entityType, entityId || null, JSON.stringify(details || {}), nowIso());
}

function migrateUsersTableIfNeeded() {
  // Existing installs created before the technical_expert/audit_officer/asset_officer
  // roles existed have a stricter CHECK constraint baked into the users table.
  // SQLite can't ALTER a CHECK constraint directly, so rebuild the table if needed.
  const row = db
    .prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'")
    .get();
  if (row && row.sql && !row.sql.includes("technical_expert")) {
    console.log("Migrating users table to support new clearance-signatory roles...");
    db.exec(`
      ALTER TABLE users RENAME TO users_old;
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('superadmin','ictadmin','hod','inventoryadmin','technical_expert','audit_officer','asset_officer')),
        department TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_by INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY(created_by) REFERENCES users(id)
      );
      INSERT INTO users(id, name, email, password_hash, role, department, is_active, created_by, created_at)
        SELECT id, name, email, password_hash, role, department, is_active, created_by, created_at FROM users_old;
      DROP TABLE users_old;
    `);
    console.log("Migration complete.");
  }
}

function seedIfEmpty() {
  const userCount = db.prepare("SELECT COUNT(*) AS c FROM users").get().c;
  if (userCount === 0) {
    const defaultPassword = "Passw0rd!";
    const hash = bcrypt.hashSync(defaultPassword, 10);
    const insert = db.prepare(
      `INSERT INTO users(name, email, password_hash, role, department, is_active, created_at)
       VALUES (?,?,?,?,?,1,?)`
    );
    insert.run("System Super Admin", "superadmin@plasu.edu.ng", hash, "superadmin", "ICT/Admin", nowIso());
    insert.run("ICT Admin", "ictadmin@plasu.edu.ng", hash, "ictadmin", "ICT Unit", nowIso());
    insert.run("HOD Computer Science", "hod.cs@plasu.edu.ng", hash, "hod", "Computer Science", nowIso());
    insert.run("Inventory Admin", "inventoryadmin@plasu.edu.ng", hash, "inventoryadmin", "Central Store", nowIso());
    insert.run("Technical Expert", "technical@plasu.edu.ng", hash, "technical_expert", "Works/Technical Unit", nowIso());
    insert.run("Audit Officer", "audit@plasu.edu.ng", hash, "audit_officer", "Internal Audit Unit", nowIso());
    insert.run("Asset & Insurance Officer", "asset@plasu.edu.ng", hash, "asset_officer", "Asset Management Unit", nowIso());
    console.log(`Seeded 7 default users. Default password for all: ${defaultPassword}`);
  }

  // Backfill the 3 new signatory accounts for installs that already had users
  // seeded before these roles existed.
  const defaultPassword = "Passw0rd!";
  const newAccounts = [
    ["Technical Expert", "technical@plasu.edu.ng", "technical_expert", "Works/Technical Unit"],
    ["Audit Officer", "audit@plasu.edu.ng", "audit_officer", "Internal Audit Unit"],
    ["Asset & Insurance Officer", "asset@plasu.edu.ng", "asset_officer", "Asset Management Unit"],
  ];
  for (const [name, email, role, department] of newAccounts) {
    const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (!exists) {
      const hash = bcrypt.hashSync(defaultPassword, 10);
      db.prepare(
        `INSERT INTO users(name, email, password_hash, role, department, is_active, created_at)
         VALUES (?,?,?,?,?,1,?)`
      ).run(name, email, hash, role, department, nowIso());
      console.log(`Added missing default account: ${email} (password: ${defaultPassword})`);
    }
  }

  const itemCount = db.prepare("SELECT COUNT(*) AS c FROM items").get().c;
  if (itemCount === 0) {
    const ictadmin = db.prepare("SELECT id FROM users WHERE email = ?").get("ictadmin@plasu.edu.ng");
    if (ictadmin) {
      const insertItem = db.prepare(
        `INSERT INTO items(code, name, description, unit, quantity_on_hand, reorder_level, is_active, created_by, created_at)
         VALUES (?,?,?,?,?,?,1,?,?)`
      );
      insertItem.run("ITM-0001", "A4 Paper Ream", "White A4 photocopy paper, 80gsm", "ream", 200, 30, ictadmin.id, nowIso());
      insertItem.run("ITM-0002", "HB Pencil", "Standard HB writing pencil", "ea", 500, 100, ictadmin.id, nowIso());
      insertItem.run("ITM-0003", "Printer Toner (HP 12A)", "Black toner cartridge", "ea", 15, 5, ictadmin.id, nowIso());
      insertItem.run("ITM-0004", "Box File", "Standard cardboard box file", "ea", 80, 20, ictadmin.id, nowIso());
    }
  }
}

initSchema();
migrateUsersTableIfNeeded();
seedIfEmpty();

module.exports = { db, ROLES, SIGNOFF_ROLES, nowIso, nextReqNo, audit };
