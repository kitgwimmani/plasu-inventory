// routes/items.js
// All authenticated roles may view inventory (needed by HOD to raise requisitions).
// Only superadmin and ictadmin may create new inventory item master records.
// Only inventoryadmin (or superadmin/ictadmin) may record incoming stock receipts.
const express = require("express");
const { db, audit, nowIso } = require("../db/init");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", (req, res) => {
  const items = db
    .prepare("SELECT * FROM items WHERE is_active = 1 ORDER BY name ASC")
    .all();
  res.json({ items });
});

router.post("/", requireRole("superadmin", "ictadmin"), (req, res) => {
  const { code, name, description, unit, reorder_level, quantity_on_hand } = req.body || {};
  if (!code || !name || !unit) {
    return res.status(400).json({ error: "Item code, name and unit are required." });
  }
  const existing = db.prepare("SELECT id FROM items WHERE code = ?").get(code);
  if (existing) {
    return res.status(409).json({ error: "An item with this code already exists." });
  }
  const info = db
    .prepare(
      `INSERT INTO items(code, name, description, unit, quantity_on_hand, reorder_level, is_active, created_by, created_at)
       VALUES (?,?,?,?,?,?,1,?,?)`
    )
    .run(
      code,
      name,
      description || "",
      unit,
      Number(quantity_on_hand) || 0,
      Number(reorder_level) || 0,
      req.user.id,
      nowIso()
    );
  audit(req.user.id, req.user.email, "CREATE_ITEM", "ITEM", info.lastInsertRowid, { code, name });
  const item = db.prepare("SELECT * FROM items WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ item });
});

router.put("/:id", requireRole("superadmin", "ictadmin"), (req, res) => {
  const { id } = req.params;
  const { name, description, unit, reorder_level, is_active } = req.body || {};
  const item = db.prepare("SELECT * FROM items WHERE id = ?").get(id);
  if (!item) return res.status(404).json({ error: "Item not found." });

  db.prepare(
    `UPDATE items SET
      name = COALESCE(?, name),
      description = COALESCE(?, description),
      unit = COALESCE(?, unit),
      reorder_level = COALESCE(?, reorder_level),
      is_active = COALESCE(?, is_active)
     WHERE id = ?`
  ).run(name || null, description ?? null, unit || null, reorder_level ?? null, is_active === undefined ? null : is_active, id);

  audit(req.user.id, req.user.email, "UPDATE_ITEM", "ITEM", id, req.body);
  const updated = db.prepare("SELECT * FROM items WHERE id = ?").get(id);
  res.json({ item: updated });
});

// Record incoming stock (increases quantity_on_hand). Restricted to inventory managers.
router.post("/:id/receive", requireRole("inventoryadmin", "superadmin", "ictadmin"), (req, res) => {
  const { id } = req.params;
  const { qty, remarks } = req.body || {};
  const item = db.prepare("SELECT * FROM items WHERE id = ?").get(id);
  if (!item) return res.status(404).json({ error: "Item not found." });
  const q = Number(qty);
  if (!q || q <= 0) {
    return res.status(400).json({ error: "Quantity must be a positive number." });
  }

  const tx = db.transaction(() => {
    db.prepare("UPDATE items SET quantity_on_hand = quantity_on_hand + ? WHERE id = ?").run(q, id);
    db.prepare(
      `INSERT INTO stock_receipts(item_id, qty, remarks, received_by, created_at) VALUES (?,?,?,?,?)`
    ).run(id, q, remarks || "", req.user.id, nowIso());
  });
  tx();

  audit(req.user.id, req.user.email, "RECEIVE_STOCK", "ITEM", id, { qty: q, remarks });
  const updated = db.prepare("SELECT * FROM items WHERE id = ?").get(id);
  res.json({ item: updated });
});

module.exports = router;
