// routes/users.js
// Only superadmin and ictadmin may create/manage user accounts.
const express = require("express");
const bcrypt = require("bcryptjs");
const { db, audit, nowIso, ROLES } = require("../db/init");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth);

router.get("/", requireRole("superadmin", "ictadmin"), (req, res) => {
  const users = db
    .prepare(
      "SELECT id, name, email, role, department, is_active, created_at FROM users ORDER BY created_at DESC"
    )
    .all();
  res.json({ users });
});

router.post("/", requireRole("superadmin", "ictadmin"), (req, res) => {
  const { name, email, password, role, department } = req.body || {};
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "Name, email, password and role are required." });
  }
  if (!ROLES.includes(role)) {
    return res.status(400).json({ error: "Invalid role specified." });
  }
  if (String(password).length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const emailNorm = String(email).toLowerCase().trim();
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(emailNorm);
  if (existing) {
    return res.status(409).json({ error: "A user with this email already exists." });
  }

  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare(
      `INSERT INTO users(name, email, password_hash, role, department, is_active, created_by, created_at)
       VALUES (?,?,?,?,?,1,?,?)`
    )
    .run(name, emailNorm, hash, role, department || null, req.user.id, nowIso());

  audit(req.user.id, req.user.email, "CREATE_USER", "USER", info.lastInsertRowid, { email: emailNorm, role });
  const user = db
    .prepare("SELECT id, name, email, role, department, is_active, created_at FROM users WHERE id = ?")
    .get(info.lastInsertRowid);
  res.status(201).json({ user });
});

router.put("/:id", requireRole("superadmin", "ictadmin"), (req, res) => {
  const { id } = req.params;
  const { name, role, department, is_active } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id);
  if (!user) return res.status(404).json({ error: "User not found." });

  if (role && !ROLES.includes(role)) {
    return res.status(400).json({ error: "Invalid role specified." });
  }
  // Prevent locking out the last active superadmin account.
  if ((role && role !== "superadmin" && user.role === "superadmin") || is_active === 0) {
    if (user.role === "superadmin") {
      const activeSuperadmins = db
        .prepare("SELECT COUNT(*) AS c FROM users WHERE role='superadmin' AND is_active=1 AND id != ?")
        .get(id).c;
      if (activeSuperadmins === 0) {
        return res.status(400).json({ error: "Cannot remove or deactivate the last active superadmin." });
      }
    }
  }

  db.prepare(
    `UPDATE users SET
      name = COALESCE(?, name),
      role = COALESCE(?, role),
      department = COALESCE(?, department),
      is_active = COALESCE(?, is_active)
     WHERE id = ?`
  ).run(name || null, role || null, department ?? null, is_active === undefined ? null : is_active, id);

  audit(req.user.id, req.user.email, "UPDATE_USER", "USER", id, { name, role, department, is_active });
  const updated = db
    .prepare("SELECT id, name, email, role, department, is_active, created_at FROM users WHERE id = ?")
    .get(id);
  res.json({ user: updated });
});

router.post("/:id/reset-password", requireRole("superadmin", "ictadmin"), (req, res) => {
  const { id } = req.params;
  const { newPassword } = req.body || {};
  if (!newPassword || String(newPassword).length < 6) {
    return res.status(400).json({ error: "New password must be at least 6 characters." });
  }
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id);
  if (!user) return res.status(404).json({ error: "User not found." });

  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, id);
  audit(req.user.id, req.user.email, "RESET_PASSWORD", "USER", id, {});
  res.json({ ok: true });
});

module.exports = router;
