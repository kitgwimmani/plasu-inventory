// routes/requisitions.js
// Workflow:
//  1. HOD creates a requisition (status: pending) from available inventory items.
//  2. InventoryAdmin reviews and approves or rejects it.
//  3. On approval, a clearance sheet with 4 signoff slots is created
//     (requester, technical expert, audit officer, asset/insurance officer).
//  4. Once all four parties have signed, InventoryAdmin issues the item(s),
//     which deducts stock from inventory and closes the requisition.
const express = require("express");
const { db, audit, nowIso, nextReqNo, SIGNOFF_ROLES } = require("../db/init");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

function getFullRequisition(id) {
  const req = db.prepare(
    `SELECT r.*, u.name AS hod_name, u.email AS hod_email,
            au.name AS approved_by_name, iu.name AS issued_by_name
     FROM requisitions r
     JOIN users u ON u.id = r.hod_id
     LEFT JOIN users au ON au.id = r.approved_by
     LEFT JOIN users iu ON iu.id = r.issued_by
     WHERE r.id = ?`
  ).get(id);
  if (!req) return null;

  const lines = db.prepare(
    `SELECT ri.*, i.code AS item_code, i.name AS item_name, i.unit, i.quantity_on_hand
     FROM requisition_items ri
     JOIN items i ON i.id = ri.item_id
     WHERE ri.requisition_id = ?`
  ).all(id);

  const signoffs = db.prepare(
    `SELECT role_label, signed, signed_by_name, signed_at FROM signoffs WHERE requisition_id = ?`
  ).all(id);

  return { ...req, lines, signoffs };
}

// List requisitions. HOD sees only their own; other roles see all (oversight/processing).
router.get("/", (req, res) => {
  let rows;
  if (req.user.role === "hod") {
    rows = db
      .prepare("SELECT * FROM requisitions WHERE hod_id = ? ORDER BY created_at DESC")
      .all(req.user.id);
  } else {
    rows = db.prepare("SELECT * FROM requisitions ORDER BY created_at DESC").all();
  }
  res.json({ requisitions: rows });
});

router.get("/:id", (req, res) => {
  const full = getFullRequisition(req.params.id);
  if (!full) return res.status(404).json({ error: "Requisition not found." });
  if (req.user.role === "hod" && full.hod_id !== req.user.id) {
    return res.status(403).json({ error: "You may only view your own requisitions." });
  }
  res.json({ requisition: full });
});

// Only HODs can raise a requisition against available inventory.
router.post("/", requireRole("hod"), (req, res) => {
  const { purpose, items } = req.body || {};
  if (!purpose || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Purpose and at least one requested item are required." });
  }

  for (const line of items) {
    if (!line.item_id || !line.qty || Number(line.qty) <= 0) {
      return res.status(400).json({ error: "Each line requires a valid item and a quantity greater than zero." });
    }
    const item = db.prepare("SELECT * FROM items WHERE id = ? AND is_active = 1").get(line.item_id);
    if (!item) {
      return res.status(400).json({ error: `Item id ${line.item_id} is not a valid, active inventory item.` });
    }
    if (Number(line.qty) > item.quantity_on_hand) {
      return res.status(400).json({
        error: `Requested quantity for "${item.name}" (${line.qty}) exceeds available stock (${item.quantity_on_hand}).`,
      });
    }
  }

  const reqNo = nextReqNo();
  const tx = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO requisitions(req_no, hod_id, department, purpose, status, created_at)
         VALUES (?,?,?,?,'pending',?)`
      )
      .run(reqNo, req.user.id, req.user.department || "", purpose, nowIso());
    const reqId = info.lastInsertRowid;
    const insertLine = db.prepare(
      `INSERT INTO requisition_items(requisition_id, item_id, qty_requested, remarks) VALUES (?,?,?,?)`
    );
    for (const line of items) {
      insertLine.run(reqId, line.item_id, Number(line.qty), line.remarks || "");
    }
    return reqId;
  });
  const reqId = tx();

  audit(req.user.id, req.user.email, "CREATE_REQUISITION", "REQUISITION", reqId, { req_no: reqNo, purpose });
  res.status(201).json({ requisition: getFullRequisition(reqId) });
});

// Only InventoryAdmin approves requisitions.
router.put("/:id/approve", requireRole("inventoryadmin"), (req, res) => {
  const { id } = req.params;
  const requisition = db.prepare("SELECT * FROM requisitions WHERE id = ?").get(id);
  if (!requisition) return res.status(404).json({ error: "Requisition not found." });
  if (requisition.status !== "pending") {
    return res.status(400).json({ error: "Only pending requisitions can be approved." });
  }

  const tx = db.transaction(() => {
    db.prepare(
      "UPDATE requisitions SET status='approved', approved_by=?, approved_at=? WHERE id=?"
    ).run(req.user.id, nowIso(), id);
    const insertSignoff = db.prepare(
      "INSERT OR IGNORE INTO signoffs(requisition_id, role_label, signed) VALUES (?,?,0)"
    );
    for (const label of SIGNOFF_ROLES) {
      insertSignoff.run(id, label);
    }
  });
  tx();

  audit(req.user.id, req.user.email, "APPROVE_REQUISITION", "REQUISITION", id, {});
  res.json({ requisition: getFullRequisition(id) });
});

router.put("/:id/reject", requireRole("inventoryadmin"), (req, res) => {
  const { id } = req.params;
  const { reason } = req.body || {};
  const requisition = db.prepare("SELECT * FROM requisitions WHERE id = ?").get(id);
  if (!requisition) return res.status(404).json({ error: "Requisition not found." });
  if (requisition.status !== "pending") {
    return res.status(400).json({ error: "Only pending requisitions can be rejected." });
  }

  db.prepare(
    "UPDATE requisitions SET status='rejected', rejected_by=?, rejected_at=?, rejection_reason=? WHERE id=?"
  ).run(req.user.id, nowIso(), reason || "", id);

  audit(req.user.id, req.user.email, "REJECT_REQUISITION", "REQUISITION", id, { reason });
  res.json({ requisition: getFullRequisition(id) });
});

// Record or withdraw an individual signoff slot on the clearance sheet
// (requester, technical expert, audit officer, asset/insurance officer).
//
// Each party signs for themselves once logged in:
//   - "requester"        -> only the HOD who raised the requisition
//   - "technical_expert" -> only a user with the technical_expert role
//   - "audit_officer"    -> only a user with the audit_officer role
//   - "asset_officer"    -> only a user with the asset_officer role
// superadmin / ictadmin / inventoryadmin may also sign or undo any slot,
// for corrections and to keep the process moving if a signatory is unavailable.
router.put("/:id/signoff", (req, res) => {
  const { id } = req.params;
  const { role_label, signed } = req.body || {};
  if (!SIGNOFF_ROLES.includes(role_label)) {
    return res.status(400).json({ error: "Invalid signoff role." });
  }
  const requisition = db.prepare("SELECT * FROM requisitions WHERE id = ?").get(id);
  if (!requisition) return res.status(404).json({ error: "Requisition not found." });
  if (requisition.status !== "approved") {
    return res.status(400).json({ error: "Signoffs can only be recorded on approved requisitions awaiting issue." });
  }

  const isRequesterOwner = role_label === "requester" && requisition.hod_id === req.user.id;
  const isDirectSignatory = req.user.role === role_label;
  const isAdminOverride = ["superadmin", "ictadmin", "inventoryadmin"].includes(req.user.role);

  if (!isRequesterOwner && !isDirectSignatory && !isAdminOverride) {
    return res.status(403).json({ error: "You are not authorized to record this signoff." });
  }

  const signedByName = signed ? req.user.name : null;

  db.prepare(
    `UPDATE signoffs SET signed = ?, signed_by_name = ?, signed_at = ?
     WHERE requisition_id = ? AND role_label = ?`
  ).run(signed ? 1 : 0, signedByName, signed ? nowIso() : null, id, role_label);

  audit(req.user.id, req.user.email, signed ? "SIGN_CLEARANCE" : "UNDO_SIGNOFF", "REQUISITION", id, { role_label });
  res.json({ requisition: getFullRequisition(id) });
});

// Issue the requisitioned items: requires status=approved AND all 4 signoffs complete.
// Deducts stock quantities and marks the requisition as issued.
router.put("/:id/issue", requireRole("inventoryadmin"), (req, res) => {
  const { id } = req.params;
  const requisition = db.prepare("SELECT * FROM requisitions WHERE id = ?").get(id);
  if (!requisition) return res.status(404).json({ error: "Requisition not found." });
  if (requisition.status !== "approved") {
    return res.status(400).json({ error: "Only approved requisitions can be issued." });
  }

  const signoffs = db.prepare("SELECT * FROM signoffs WHERE requisition_id = ?").all(id);
  const allSigned = SIGNOFF_ROLES.every((label) => {
    const s = signoffs.find((x) => x.role_label === label);
    return s && s.signed;
  });
  if (!allSigned) {
    return res.status(400).json({ error: "All parties (requester, technical expert, audit officer, asset officer) must sign before issue." });
  }

  const lines = db.prepare("SELECT * FROM requisition_items WHERE requisition_id = ?").all(id);
  for (const line of lines) {
    const item = db.prepare("SELECT * FROM items WHERE id = ?").get(line.item_id);
    if (!item || item.quantity_on_hand < line.qty_requested) {
      return res.status(400).json({ error: `Insufficient stock to issue item id ${line.item_id}.` });
    }
  }

  const tx = db.transaction(() => {
    for (const line of lines) {
      db.prepare("UPDATE items SET quantity_on_hand = quantity_on_hand - ? WHERE id = ?").run(
        line.qty_requested,
        line.item_id
      );
    }
    db.prepare("UPDATE requisitions SET status='issued', issued_by=?, issued_at=? WHERE id=?").run(
      req.user.id,
      nowIso(),
      id
    );
  });
  tx();

  audit(req.user.id, req.user.email, "ISSUE_REQUISITION", "REQUISITION", id, {});
  res.json({ requisition: getFullRequisition(id) });
});

module.exports = router;
