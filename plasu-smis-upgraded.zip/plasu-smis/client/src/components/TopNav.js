import React from "react";
import { Navbar, Nav, Container, Dropdown, NavDropdown } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useAuth, ROLE_LABELS } from "../context/AuthContext";
import NotificationBell from "./NotificationBell";

const ADMIN_ROLES = ["superadmin", "ictadmin"];

export default function TopNav() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const isAdmin = ADMIN_ROLES.includes(user.role);

  return (
    <Navbar expand="lg" className="plasu-navbar px-3" variant="dark">
      <Container fluid>
        <Navbar.Brand as={Link} to="/dashboard" className="d-flex align-items-center gap-2">
          <img src="/logo.png" alt="PLASU Bokkos logo" height="38" />
          <span className="plasu-brand-title">
            PLASU SMIS
            <small>Store Management Information System</small>
          </span>
        </Navbar.Brand>
        <div className="d-flex align-items-center order-lg-3 gap-1">
          <NotificationBell />
          <Dropdown align="end">
            <Dropdown.Toggle as="a" className="nav-link" role="button" style={{ cursor: "pointer" }}>
              <i className="bi bi-person-circle me-1" />
              {user.name} <span className="text-warning">({ROLE_LABELS[user.role]})</span>
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item as={Link} to="/change-password">
                <i className="bi bi-key me-2" />Change Password
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item onClick={handleLogout}>
                <i className="bi bi-box-arrow-right me-2" />Log Out
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <Navbar.Toggle aria-controls="main-navbar" className="order-lg-2" />
        <Navbar.Collapse id="main-navbar" className="order-lg-1">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/dashboard"><i className="bi bi-speedometer2 me-1" />Dashboard</Nav.Link>
            <Nav.Link as={Link} to="/inventory"><i className="bi bi-box-seam me-1" />Inventory</Nav.Link>
            <Nav.Link as={Link} to="/requisitions"><i className="bi bi-file-earmark-text me-1" />Requisitions</Nav.Link>
            <Nav.Link as={Link} to="/reports"><i className="bi bi-printer me-1" />Reports</Nav.Link>
            {isAdmin && (
              <NavDropdown title={<><i className="bi bi-gear me-1" />Admin</>} id="admin-nav-dropdown">
                <NavDropdown.Item as={Link} to="/users"><i className="bi bi-people me-2" />Users</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/departments"><i className="bi bi-diagram-3 me-2" />Departments</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/categories"><i className="bi bi-tags me-2" />Item Categories</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item as={Link} to="/audit"><i className="bi bi-clock-history me-2" />Audit Log</NavDropdown.Item>
              </NavDropdown>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
