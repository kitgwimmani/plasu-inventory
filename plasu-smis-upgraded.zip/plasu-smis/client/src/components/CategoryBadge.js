import React from "react";
import { Badge } from "react-bootstrap";

const PALETTE = [
  { bg: "#e8f5ea", fg: "#0f6b2c" },
  { bg: "#fdf1dc", fg: "#8a5c00" },
  { bg: "#e7eefc", fg: "#2f5fd1" },
  { bg: "#fbe9ec", fg: "#b3261e" },
  { bg: "#f1e9fb", fg: "#6a3fb3" },
  { bg: "#e3f6f5", fg: "#0e7c78" },
];

function hashColor(text) {
  let hash = 0;
  for (let i = 0; i < (text || "").length; i++) hash = text.charCodeAt(i) + ((hash << 5) - hash);
  return PALETTE[Math.abs(hash) % PALETTE.length];
}

export default function CategoryBadge({ name, code }) {
  if (!name) return <span className="text-muted small">Uncategorized</span>;
  const { bg, fg } = hashColor(name);
  return (
    <Badge style={{ backgroundColor: bg, color: fg, fontWeight: 600 }} title={name}>
      {code || name}
    </Badge>
  );
}
